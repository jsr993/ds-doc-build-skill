---
name: spec-kit-docs
description: "Autonomously builds component documentation in Figma on the ds-* engine (the «Component Spec Kit» library). Input — a link to the component itself (COMPONENT_SET or COMPONENT); nothing else is required. The skill takes an inventory of variants, properties and anatomy and assembles a section of three pages: changelog, specification, components. It asks almost no questions — built for documenting many components in a row. Use when given a Figma component link and asked to «document this component in Figma», «build component docs», «generate ds-doc section», or in Russian: «собери документацию», «задокументируй компонент», «сделай страницы доки», «оформи по шаблону документации», «построй ds-doc». Requires Figma MCP with write access."
---

# Building component documentation in Figma

Input — a link to a product component. Output — a SECTION of three pages assembled from `ds-*` engine components. Nothing is drawn from scratch: patterns are instantiated and filled.

**Three pages, always the same three:** `changelog`, `specification`, `components`. Documentation does not exist without them; the skill builds nothing else. No page selection, no plan confirmation — from link to finished section without stopping.

**Distribution model.** The engine is a Figma file the user duplicates or attaches as a library. The skill is portable: it finds `ds-*` by name or by key, never by id. All documentation visuals come from the `theme` variable collection — the user changes typography, colours, radii and spacing there, and the documentation restyles wholesale. The skill never interferes with that mechanism.

## Required context

**Version 6.3.** `SKILL.md` and `references/` ship as one archive and are versioned together — a folder from another generation is a broken install, not a variant.

| File | When to read |
|---|---|
| `references/ds-engine-map.md` | before the first action — every `ds-*`, node-ids, keys, properties |
| `references/build-recipes.md` | before the first action — Plugin API snippets |
| `references/annotations.md` | before building Specification |
| `references/locales/<lang>.md` | after the language is determined — exactly one file |
| `references/contract-template.md` | only when explicitly asked to export markdown |

## How to run it

The skill needs three capabilities: execute JS in the Figma file, capture an image of a node, and write access. Any one missing — stop and say which.

| Harness | Execute | Capture |
|---|---|---|
| Claude Code + Figma MCP | `use_figma`, with `figma-use` in `skillNames` — mandatory before **every** call | `get_screenshot` |
| Any model with Figma MCP | the MCP tool that runs JS | the MCP tool returning a node image |
| An agent inside Figma | Plugin API directly | by its own means |

Call contract:

- one call — one logical step; a page is never built whole in one call;
- `return` instead of `console.log`: only the returned value is visible;
- `setCurrentPageAsync` — exactly once per call, and pages do not load without it;
- return the IDs of every node created or mutated;
- a failed call is never blindly retried: read the error, fix, retry. A failed script does not execute partially.

## Language

**Documentation language = the language the user wrote the request in.** Russian request → Russian texts, `ru.md`; English request → English texts, `en.md`. Read exactly one locale file; reading both wastes context.

Safeguard: after the engine is resolved, read the value of the specification header title variable and compare its language with the chosen one. A mismatch is **not an error and not a question** — name it in the report («headings come from the file in English, generated texts are Russian») and continue. The file may be intentionally mixed.

## Inviolable rules

1. **The library is mandatory.** The engine is recognised by its `theme` variable collection — in an attached library (named «Component Spec Kit» by default) or locally in the file. Neither present → stop and ask to attach it (step 0). It cannot be attached from code.
2. **Input is the component itself.** `COMPONENT_SET` or `COMPONENT`. An instance, frame, section or group → stop.
3. **Never touch the source component.** Properties, layers, name, description — read only. The single exception is moving the set itself into `Slot Component` (6.3) — that is part of the build and needs no confirmation.
4. **Never touch the header.** `Title` is the section name, `Description` its subtitle; both are bound to `text/docs-header/<pattern>/*` variables. Never put the component name there. Any `setProps` on them severs the variable binding.
5. **No numbers in text.** Sizes, spacing, radii, colours, typography → annotations with `properties` and measurements.
6. **Never set visuals by value.** No `fills`, `fontSize`, `fontName`, `cornerRadius`, `strokeWeight` as literals: everything comes from the engine through `theme` variables; a hand-set value overrides the theme. Copy geometry from neighbouring engine nodes. Never write into `theme`. Exception — the SECTION (5.1), and even that by binding only.
7. **Write only inside your own SECTION.**
8. **Facts from the component, wording from templates.** Variants, states, anatomy and property order come only from the inventory; inventing them is forbidden. Headings and descriptions the skill writes itself using the templates in the locale file — and lists everything generated in the report. What must never be written even from a template — see «Texts».
9. **Incrementally.** A page is built over several calls when its block count demands it — the call contract's «a page is never built whole in one call» wins over the old one-call habit. A screenshot check closes every page, not every call.
10. **Return the IDs** of every node created.

## Pipeline

```
0 Readiness → 1 Input and inventory → 2 Staging → 3 Three pages → 4 Handover
```

Each step reports its facts before acting — what was read, what was found, what is about to be written. A report is not a question: state the facts and continue. **From link to finished section there are no confirmations of any kind** — the build runs to the end. Stops happen only where «stop» is written, and every one of them is a dead end, not a checkpoint: unreadable references, no library, input that is not a component, a missing `ds-*` or variable. Nothing is written to the file before step 2 closes.

### 0. Readiness

**Completeness.** Read the five files from the table (the locale counts once the language is known). If any cannot be read — name it, diagnose the install, and finish. Do not reconstruct content by reading the Figma file and do not work «from memory»: without the engine map the keys and node-ids have nowhere to come from, the result differs from run to run, and the finished section in Figma looks the same either way.

**Diagnose before blaming the unpack.** List what `references/` actually holds — a stale folder names its own generation:

| What you see | What it means |
|---|---|
| `interview.md` or `designers.md` present | the folder predates 3.0 |
| `execution.md` present | the folder predates 4.0, where it was folded into `SKILL.md` |
| `locales/` missing | the folder predates 3.1 |
| the folder is named `ds-doc-build` | it predates 6.0, where the skill was renamed `spec-kit-docs` |
| no `references/` at all, or a table file missing with none of the markers above | an incomplete unpack |

The stop message states: the version from `SKILL.md`, the files found, the files missing, the stale markers, and the verdict — **«reinstall the whole folder from `dist/spec-kit-docs.skill`, do not unpack over the old one»** when markers are present, **«add the missing files»** when they are not.

**Never edit the required-context table to fit a broken folder.** Making the error disappear that way silently rolls the skill back a generation: the pipeline then references steps that no longer exist.

**Library.** `figma.teamLibrary.getAvailableLibraryVariableCollectionsAsync()`:

The engine is recognised **by the `theme` collection, not by library name**: the owner may rename the file, a user may publish their own copy under their own name. «Component Spec Kit» is the default name and a hint for humans, not a condition.

| Found | Action |
|---|---|
| a `theme` collection in one attached library | proceed; resolve the engine **by `key`**; name the `libraryName` in the report |
| several such libraries | **stop**: list the names, ask which one is the engine |
| no library, but the file has a local `theme` collection and `ds-*` components | proceed on the local copy; resolve **by name**; note it in the report |
| neither | **stop**: ask to attach the engine via `Assets` → `Libraries` (named «Component Spec Kit» by default) |

A library cannot be attached from code — only a human through the UI. So the check ends with a request, not an attempted fix.

### 1. Input and inventory

`fileKey` and `node-id` from the URL (hyphen between numbers → colon). No `node-id` — ask for it.

| Input | Action |
|---|---|
| `COMPONENT_SET` | work with it |
| `COMPONENT` with no set parent | work with it; the `components` page gets no axis labels |
| `COMPONENT` inside a set | climb to the parent, no questions |
| `INSTANCE`, `FRAME`, `SECTION`, `GROUP`, anything else | **stop** |

Stop = create nothing, do not descend into the node, do not guess. Name the type and name of what arrived, say a component link is needed, finish. Reason: the same node later goes into `Slot Component` (6.3) — an instance or frame cannot go there.

**Inventory (read-only, recipe 1).** Capture: name, `key`, `description`, `documentationLinks`; `componentPropertyDefinitions`; the actual variant combinations (not the cartesian product); the `defaultVariant` layer tree to depth 3; nested instances; tokens via `get_variable_defs`.

**Preserve property order verbatim** — specification blocks follow it. Do not sort.

**Names verbatim, typos included.** Search and verification run on names; a mismatch is worse than a typo. List noticed typos in the report as a separate item — a find for the owner, not a reason to edit the documentation text.

Report before moving on: name, variant count, axes with values, properties in declaration order, where the lead comes from.

### 2. Staging (recipes 2, 2a)

Engine resolution: by key for a library (`importComponentByKeyAsync` / `importComponentSetByKeyAsync`), by name over pages for a local copy. **Components of an attached library cannot be found by name** — the Plugin API does not enumerate them; only key import works.

Keys in `ds-engine-map.md` are the owner's library keys. If the user published **their own** copy, the keys differ. Then: ask them to drag any `ds-doc/*` from `Assets` onto the canvas once, read `instance.mainComponent.key`, and proceed from it, keeping harvested keys in build memory.

Name matching is **exact**, engine typos included. Do not pick similar names. Nothing found — stop and return three lists: expected, found, missing, plus the probable cause.

**Rebuild.** Before creating the section, look for a SECTION named after the component on the current page. Found — this is a rebuild: take the changelog version base from the top `ds-doc/changelog/log` entry of its `changelog` page, build the new section to the right of the old one, and **do not touch or delete the old one** — offer its removal in the report; the owner decides. Not found — first build, version `1.0.0`.

Then one call: `setCurrentPageAsync` (exactly once) → load fonts harvested from engine nodes, never hardcoded → a `SECTION` named after the component to the right of the rightmost node → style it (5.1).

#### 5.1 Styling the SECTION

**One section — one tier, whole.** A component's documentation section carries tier `01` of the section tokens in every property; a family section wrapping several component sections carries tier `02` the same way. Mixing tiers within one section is an error.

| Property | Variable (tier 01) | Engine constant |
|---|---|---|
| radius, all four corners | `layers/section/radius/ds-radius-section-01` | — |
| bottom fill | `colors/section/ds-section-01` | opacity 1 |
| top fill | `colors/section/ds-section-accent` | the accent film, ~1 % — copy the exact opacity from a finished section in the file |
| stroke colour | `colors/section/ds-section-border-01` | opacity 1 |
| stroke weight | `layers/section/border/ds-section-border-01` | — **bound, never the literal `1`**: the theme decides whether a border exists, `lite` resolves it to 0 |

Alignment `INSIDE` is the one engine constant left on the stroke. Everything else — **only `setBoundVariable` and `setBoundVariableForPaint`**. A variable missing from the collection — stop and name it, never substitute a hand-picked colour. If the file already has a finished documentation section, copy the settings from it — with one check: the stroke colour must come from `colors/section/ds-section-border-*`, not from the section fill (found in the field: example sections carrying the fill colour on the stroke, which disappears against the background in `enterprise`).

Layout: 100 padding from the section edge on all sides, pages left to right with a 200 step.

### 3. Three pages — each built incrementally

Pattern instance → `detachInstance()` → fill `Content`. Detach is mandatory: patterns have no public properties and the number of blocks is unknown in advance. After detach `Header` remains a `ds-doc/header` instance — do not touch it.

**The frame name comes from the header `Title` of that same page.** After detach, read `Title` from the `ds-doc/header` instance and assign it to `frame.name`. Do not invent names and do not hardcode a list: `Title` is bound to `theme`, so frame names follow the library's theme and language. `Title` empty — use the pattern name without the `ds-doc/` prefix. The name is a snapshot at build time; a rebuild picks up the new value.

After each page — capture an image and check; fix layout immediately.

#### 6.1 `ds-doc/changelog`

Only `ds-doc/changelog/log` entries, one entry = one change, newest first on top (`insertChild(0, …)`).

A first build writes one entry:

| Field | Source |
|---|---|
| version | `1.0.0` |
| `Type` | `New` |
| date | today, leading zeros required (`01`, not `1`), two-digit year |
| description | the `changelog.first-entry` template from the locale |
| `Designers` | **do not touch the slot** — the component default stays |
| `Show File` | `false`; do not fill the `File` slot; do not change `✱ Image` |
| `Show Description` | `true` |

On a rebuild over existing documentation, the version counts from the top entry:

| `Type` | Meaning | Version |
|---|---|---|
| `New` | new component version | `Major+1`, `Minor=0`, `Patch=0` |
| `Changed` | rework | `Minor+1`, `Patch=0` |
| `Fixed` | fix | `Patch+1` |

The type comes from what the user said. Nothing said — `Changed`. Backdate only on explicit request.

#### 6.2 `ds-doc/specification`

**Lead** — a `ds-doc/specification/paragraph` directly in `Content`, not in a `Group`. `Show Title = false`, `Description` only. Source: a non-empty component `description` — **verbatim**. Empty — generate from the locale lead template.

**Anatomy** — a `Group`: `ds-doc/specification/paragraph H1` (`Title` and `Description` from the locale `anatomy.*` keys) + one `ds-doc/specification/component Type=Structure` per configuration, `Title` = configuration name, `Show Desciption = false`, a variant instance in `Slot Structure`.

Details go on layers inside the instance as annotations: purpose in `labelMarkdown`, values in `properties`. Every layout annotated. With several configurations do **not duplicate** annotations: the first carries the shared architecture, each next one only its differences.

**Then — one block per VARIANT axis, in `componentPropertyDefinitions` order.** Properties of other types do not become blocks: TEXT and INSTANCE_SWAP have no enumerable values to tabulate — list them in the report as properties without a block. BOOLEAN gets a block only with display logic of its own (see exceptions). A block = a `Group` of two nodes:

1. `ds-doc/specification/paragraph Type=H1` — `Title` from the locale glossary, `Description` from the locale template;
2. `ds-doc/specification/component Type=State`, `Show Title = false`, `Show Desciption = false`; in `Slot State` — one `ds-doc/specification/component/state` per value.

Row descriptions: **on** for configuration, style and size axes, **off** for states — a state name speaks for itself.

Exceptions: `Selected` is a row inside the States block, not a separate block. A boolean property becomes a block if it has display logic of its own.

Sizes — with an `addMeasurement` ruler. Styles — a `properties: ["fills"]` annotation on the preview.

#### 6.3 `ds-doc/components`

**One `Name Component` block per component.** Splitting into blocks per axis pair is an error. A family of several sets is named with a slash, one block each, still one frame inside a block.

| Node | Content |
|---|---|
| `Name` | `Name Component#10010:1` = component name; `ds-doc/changelog/log/version` = current version |
| `Slot Component` | **one node** — the component itself, all variants, in its native layout |
| `Horizontal Props` | `Line[0]` = axis name (`Large=True`), `Line[1]` = values |
| `Vertical Props` | one `Line` per nesting level; the innermost level is a frame with a `Line` per row block |

**Axis order comes from the set's geometry, not from declaration order.** The labels sit around the component as it is actually laid out, so read that layout: cluster the variants by `x` for the columns axis, by `y` for the vertical levels, outermost cluster first. Declaration order decides the specification blocks; the component page follows the eye. Levels: `Vertical=True` on all; major level `Large=True`, auxiliary `Large=False`. Labels are verbatim VARIANT values.

Bracket heights and gaps come from the same geometry: a level's label spans its cluster, so its height is the cluster's height. Give labels enough width for their text — a narrow instance wraps the caption mid-word.

**The move is unconditional.** The set goes into `Slot Component` without asking — it is how this page works, not a favour to request. What changes is its parent and position on the canvas; the component itself, its properties and every instance of it elsewhere are untouched. Name the move in the report: where the set came from and where it now lives.

On a **rebuild** the set moves out of the previous section's slot into the new one — a node lives in one place only. The old section keeps its pages and labels with an empty `Slot Component`; say so in the report and offer to delete it. Do not delete it unasked.

### 4. Handover

**Fit the section last**, when all heights are final: size = content bounds plus 100 on each side, via `resizeWithoutConstraints`. `SECTION` has no auto-layout and never hugs by itself.

Report: link to the section, the three pages, block and variant counts, **the list of generated texts**, source typos noticed, what remains unfilled. Labels — from the locale `report` section.

Markdown contract per `contract-template.md` — only if asked.

## Texts

The skill writes wording itself. Tone — dry, descriptive, no judgements or recommendations. Language — per the «Language» section; the templates, glossary and fixed strings live in `references/locales/<lang>.md`.

**Never generate** — leave empty and put in the report:

- when to use which configuration;
- how styles differ in meaning rather than looks;
- text and microcopy rules;
- do / don't recommendations;
- an anatomy layer's purpose when it does not follow from the layer name.

An empty block beats a plausible fabrication: generated text must be a verifiable restatement of the inventory, not a guess at the author's intent.

An anatomy layer whose purpose cannot be derived still gets annotated — the checklist requires a mark on every layout. `labelMarkdown` — the layer name in bold, no explanation; fill `properties` as usual. The layer itself goes into the report as a gap: the owner supplies the meaning.

## Checklist

1. The source `componentPropertyDefinitions` match before and after.
2. Exactly three pages built, everything inside one SECTION.
3. Headers untouched, `theme` bindings intact, no component name in them. Every frame name equals its header `Title`.
4. No created node has hand-set visuals; nothing written into `theme`.
5. No numbers in text.
6. Annotations on every anatomy layout, `properties` and category filled, none duplicated across configurations.
7. Specification blocks follow component property order.
8. `ds-doc/components` — one block, one node in `Slot Component`; axis labels verbatim.
9. Changelog: version and type by rule, date with leading zeros, `Designers` untouched, `Show File = false`.
10. Every page screenshot reviewed; no overflows or overlaps.
11. SECTION styled with variable bindings and fitted to content with 100 padding.
12. The report lists: generated texts, source typos, the unfilled.
